<div class="<?php echo $class; ?>">
    <p><?php echo $message; ?></p>
</div>
